# README

J'ai mis en place un déploiement rapide d'une VM Ubuntu avec VirtualBox et Vagrant. Il faut tout d'abord installer VirtualBox 
et Vagrant. J'ai testé avec VirtualBox 5.2.8 r121009 et Vagrant 2.0.2 sur Linux Mint.
Ensuite, unzip l'archive `vagrant_puphpet.zip`, se déplacer dans le dossier créé avec un terminal puis exécuter `vagrant up`.
Ça prend bien 5 min, ensuite avec `vagrant ssh` vous pourrez vous connecter en ssh sur votre machine. Elle a une 
IP = 192.168.1.42. Dans le dossier /home/vagrant/yourquiz de la VM vous retrouverez tout le contenu du repo. 
Faut se déplacer dans le dossier `server` et lancer `nodemon`. Je vous conseille de copier le contenu du fichier host que je 
mets en exemple dans ce dossier, comme ça dans le code client on peut remplacer tous les appels au serveur "localhost" par 
"yourquiz.dev".

Vous pouvez lire ce tuto si vous voulez voir comment ça marche 
(https://www.supinfo.com/articles/single/193-deployer-son-environnement-dev-avec-vagrant-puphpet). Ça utilise ce site pour 
générer la config : https://puphpet.com
